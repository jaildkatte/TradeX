<?php
return [
    'Book' => [
        'desc' => 'A fantasy novel with beautiful illustrations.',
        'img' => 'https://glorydaysfinegoods.com/cdn/shop/files/34a_b41a51d2-9657-4665-a2d7-c3e561dbde90.jpg?v=1687235950&width=1100'
    ],
    'Hat' => [
        'desc' => 'A stylish hat, barely used.',
        'img' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTo5JA5aSBjct6lkQvnXSjsS1bpvoWFRzoP4A&s'
    ],
    'Backpack' => [
        'desc' => 'Spacious backpack for daily use.',
        'img' => 'https://via.placeholder.com/100x100?text=Backpack'
    ],
    'Shoes' => [
        'desc' => 'Lightweight running shoes.',
        'img' => 'https://via.placeholder.com/100x100?text=Shoes'
    ],
];
