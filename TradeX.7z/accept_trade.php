<?php
session_start();
$user = $_SESSION['user'];
$index = $_POST['index'];
$trade = $_SESSION['trades'][$index];

if ($trade['to'] === $user) {
    // Remove the wanted item from this user
    $key = array_search($trade['want'], $_SESSION['items'][$user]);
    if ($key !== false) unset($_SESSION['items'][$user][$key]);

    // Give this user the offered item
    $_SESSION['items'][$user][] = $trade['offer'];

    // Transfer the wanted item to the other user
    $from = $trade['from'];
    $key2 = array_search($trade['offer'], $_SESSION['items'][$from]);
    if ($key2 !== false) unset($_SESSION['items'][$from][$key2]);
    $_SESSION['items'][$from][] = $trade['want'];

    // Remove trade
    unset($_SESSION['trades'][$index]);
    $_SESSION['trades'] = array_values($_SESSION['trades']); // Reindex
    echo "Trade accepted!";
} else {
    echo "Unauthorized action.";
}
?>
<br><a href="dashboard.php">Back</a>