</main>
<footer>
    <p>&copy; <?= date('Y') ?> Item Trading App. All rights reserved.</p>
</footer>
</body>
</html>

